@extends('layouts.app')

@section('content')
<div class="page-content">
    <div class="container-fluid">
        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif
        @if(session('error'))
            <div class="alert alert-danger">{{ session('error') }}</div>
        @endif

        <div class="card mb-3">
            <div class="card-header">
                <h5 class="mb-0">Salary Process Filter</h5>
            </div>
            <div class="card-body">
                <form method="GET" action="{{ route('admin.salary-process.index') }}" class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label class="form-label">Month <span class="text-danger">*</span></label>
                        <select name="salary_month" class="form-select" required>
                            @for($month=1; $month<=12; $month++)
                                <option value="{{ $month }}" {{ (int)$selectedMonth === $month ? 'selected' : '' }}>
                                    {{ \Carbon\Carbon::createFromDate(null, $month, 1)->format('F') }}
                                </option>
                            @endfor
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Year <span class="text-danger">*</span></label>
                        <select name="salary_year" class="form-select" required>
                            @for($year = now()->year + 1; $year >= now()->year - 5; $year--)
                                <option value="{{ $year }}" {{ (int)$selectedYear === $year ? 'selected' : '' }}>{{ $year }}</option>
                            @endfor
                        </select>
                    </div>
                    <div class="col-md-4">
                        <button type="submit" class="btn btn-primary">Show Pending Salary List</button>
                    </div>
                </form>
            </div>
        </div>

        <form method="POST" action="{{ route('admin.salary-process.store') }}" id="salaryProcessForm">
            @csrf
            <input type="hidden" name="salary_month" value="{{ $selectedMonth }}">
            <input type="hidden" name="salary_year" value="{{ $selectedYear }}">

            <div class="card mb-3">
                <div class="card-header">
                    <h5 class="mb-0">Pending Salary Employee List ({{ \Carbon\Carbon::createFromDate(null, $selectedMonth, 1)->format('F') }} {{ $selectedYear }})</h5>
                </div>
                <div class="card-body table-responsive">
                    <table class="table table-bordered align-middle" id="pendingSalaryTable">
                        <thead>
                            <tr>
                                <th>Select</th>
                                <th>Employee Name</th>
                                <th>Basic Salary</th>
                                <th>Leave Count (F/H)</th>
                                <th>Deduction</th>
                                <th>Net Amount (Editable)</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($pendingEmployees as $employee)
                                @php
                                    $employeeLeave = $leaveCounts[$employee->employee_id] ?? ['full_day' => 0, 'half_day' => 0];
                                    $oldDeduction = (float) old('deductions.' . $employee->employee_id, 200);
                                    $amount = (float) $employee->basic_salary;
                                    $oldNet = old('net_amounts.' . $employee->employee_id, max(0, $amount - $oldDeduction));
                                @endphp
                                <tr>
                                    <td>
                                        <input
                                            type="checkbox"
                                            class="form-check-input employee-checkbox"
                                            name="selected_employee_ids[]"
                                            value="{{ $employee->employee_id }}"
                                            {{ in_array($employee->employee_id, old('selected_employee_ids', [])) ? 'checked' : '' }}
                                        >
                                    </td>
                                    <td>{{ $employee->employee_name }}</td>
                                    <td>
                                        <span class="salary-amount" data-employee-id="{{ $employee->employee_id }}">{{ number_format($amount, 2) }}</span>
                                    </td>
                                    <td>
                                        <span class="badge bg-primary">F: {{ $employeeLeave['full_day'] }}</span>
                                        <span class="badge bg-info text-dark">H: {{ $employeeLeave['half_day'] }}</span>
                                    </td>
                                    <td>
                                        <input
                                            type="number"
                                            step="0.01"
                                            min="0"
                                            class="form-control deduction-input"
                                            name="deductions[{{ $employee->employee_id }}]"
                                            data-employee-id="{{ $employee->employee_id }}"
                                            value="{{ $oldDeduction }}"
                                        >
                                    </td>
                                    <td>
                                        <input
                                            type="number"
                                            step="0.01"
                                            min="0"
                                            class="form-control net-input"
                                            name="net_amounts[{{ $employee->employee_id }}]"
                                            data-employee-id="{{ $employee->employee_id }}"
                                            value="{{ $oldNet }}"
                                        >
                                        @error('net_amounts.' . $employee->employee_id)
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="6" class="text-center">No pending employees for selected month and year.</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                    @error('selected_employee_ids')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
                <div class="card-footer">
                    <div class="row align-items-end">
                        <div class="col-md-4">
                            <label class="form-label">Paid Date <span class="text-danger">*</span></label>
                            <input type="date" name="paid_date" class="form-control" value="{{ old('paid_date', now()->toDateString()) }}" required>
                            @error('paid_date')<span class="text-danger">{{ $message }}</span>@enderror
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-success">Submit Selected Salaries</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>

        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Paid Salary Employee List ({{ \Carbon\Carbon::createFromDate(null, $selectedMonth, 1)->format('F') }} {{ $selectedYear }})</h5>
            </div>
            <div class="card-body table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Employee Name</th>
                            <th>Amount</th>
                            <th>Paid Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($paidSalaryRows as $index => $row)
                            <tr>
                                <td>{{ $index + 1 }}</td>
                                <td>{{ $row->employee->employee_name ?? 'N/A' }}</td>
                                <td>{{ number_format($row->paid_amount, 2) }}</td>
                                <td>{{ $row->paid_date ? \Carbon\Carbon::parse($row->paid_date)->format('d-m-Y') : '-' }}</td>
                            </tr>
                        @empty
                            <tr><td colspan="4" class="text-center">No paid salary records found for selected period.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
(function () {
    let syncing = false;

    function getSalary(employeeId) {
        const salaryText = document.querySelector('.salary-amount[data-employee-id="' + employeeId + '"]')?.textContent || '0';
        return parseFloat(salaryText.replace(/,/g, '')) || 0;
    }

    function syncFromDeduction(employeeId) {
        if (syncing) return;
        syncing = true;
        const salary = getSalary(employeeId);
        const deductionInput = document.querySelector('.deduction-input[data-employee-id="' + employeeId + '"]');
        const netInput = document.querySelector('.net-input[data-employee-id="' + employeeId + '"]');
        const deduction = parseFloat(deductionInput?.value || 0) || 0;
        const net = Math.max(0, salary - deduction);
        if (netInput) netInput.value = net.toFixed(2);
        syncing = false;
    }

    function syncFromNet(employeeId) {
        if (syncing) return;
        syncing = true;
        const salary = getSalary(employeeId);
        const deductionInput = document.querySelector('.deduction-input[data-employee-id="' + employeeId + '"]');
        const netInput = document.querySelector('.net-input[data-employee-id="' + employeeId + '"]');
        let net = parseFloat(netInput?.value || 0) || 0;
        if (net < 0) net = 0;
        if (net > salary) net = salary;
        if (netInput) netInput.value = net.toFixed(2);
        const deduction = Math.max(0, salary - net);
        if (deductionInput) deductionInput.value = deduction.toFixed(2);
        syncing = false;
    }

    document.querySelectorAll('.deduction-input').forEach(function (input) {
        const employeeId = input.dataset.employeeId;
        input.addEventListener('input', function () { syncFromDeduction(employeeId); });
    });

    document.querySelectorAll('.net-input').forEach(function (input) {
        const employeeId = input.dataset.employeeId;
        input.addEventListener('input', function () { syncFromNet(employeeId); });
    });
})();
</script>
@endsection
